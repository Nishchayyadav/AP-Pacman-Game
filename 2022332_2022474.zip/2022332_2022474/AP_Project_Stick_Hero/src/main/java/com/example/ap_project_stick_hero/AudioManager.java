package com.example.ap_project_stick_hero;

import javafx.scene.input.KeyEvent;

public class AudioManager extends GameManager {
    private KeyEvent keyEvent;
    public AudioManager(KeyEvent keyEvent) {
        super(keyEvent);
    }

}
