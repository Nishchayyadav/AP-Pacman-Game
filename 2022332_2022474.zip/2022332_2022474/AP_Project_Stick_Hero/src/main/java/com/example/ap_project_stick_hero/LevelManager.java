package com.example.ap_project_stick_hero;

import javafx.event.Event;

public class LevelManager {
    private Event event;

    public LevelManager (Event event) {
        this.event = event;
    }

    public void loadLevel() {

    }

    public void shiftLevel() {

    }

}
