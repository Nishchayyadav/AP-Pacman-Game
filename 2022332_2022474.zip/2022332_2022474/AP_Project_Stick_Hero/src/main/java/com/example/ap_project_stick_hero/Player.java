package com.example.ap_project_stick_hero;

public class Player extends GameElement {
    private double stickLength;

    public Player(double stickLength) {
        super(1, 1);
        this.stickLength = stickLength;
    }

    @Override
    public void updateStatus() {

    }

    public void setStickLength() {

    }

    public void releaseStick() {

    }

}
